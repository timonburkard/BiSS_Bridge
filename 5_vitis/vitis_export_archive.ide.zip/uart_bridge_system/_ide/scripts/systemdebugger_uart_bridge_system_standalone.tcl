# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: C:\git\BiSS_Bridge\5_vitis\workspace\uart_bridge_system\_ide\scripts\systemdebugger_uart_bridge_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source C:\git\BiSS_Bridge\5_vitis\workspace\uart_bridge_system\_ide\scripts\systemdebugger_uart_bridge_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Zybo Z7 210351AF24F0A" && level==0 && jtag_device_ctx=="jsn-Zybo Z7-210351AF24F0A-13722093-0"}
fpga -file C:/git/BiSS_Bridge/5_vitis/workspace/uart_bridge/_ide/bitstream/biss_bridge_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw C:/git/BiSS_Bridge/5_vitis/workspace/biss_bridge/export/biss_bridge/hw/biss_bridge_wrapper_7.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source C:/git/BiSS_Bridge/5_vitis/workspace/uart_bridge/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow C:/git/BiSS_Bridge/5_vitis/workspace/uart_bridge/Debug/uart_bridge.elf
configparams force-mem-access 0
bpadd -addr &main
